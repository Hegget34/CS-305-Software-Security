package com.snhu.sslserver;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

@RestController
public class ServerController {
    @GetMapping("/hash")
    public String myHash() {
        String data = "Trevor Hegge Check Sum!";
        String algorithm = "SHA-256";
        
        try {
            MessageDigest digest = MessageDigest.getInstance(algorithm);
            byte[] encodedHash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedHash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            
            return "Data: " + data + "<br/>Hash Value: " + hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            return "Error generating hash";
        }
    }
}